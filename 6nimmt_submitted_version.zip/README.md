# Blackjack
C++, QT library (GUI), Eclipse IDE and QT IDE - An implementation of the Blackjack using a graphical user interface provide by cross-platform library QT. Features include, Human vs. Computer logic with detailed statistics with winning/losing/drawing strategies. 

Features include:

<ul>Human vs Computer Logic</ul>
<ul>Gamescoring System</ul>
<ul>Current and Total hand values</ul>
<ul>Current Status (Bust or Stick)</ul>
<ul>Dealer (Computer automatically sticks at 16 or over).</ul>
<ul>Full 52 card deck </ul>

<p align="center">
<img src="http://i.imgur.com/HEOTHv3.png" /img>
<img src="http://i.imgur.com/x4SpaoD.png" /img>
<img src="http://i.imgur.com/qxG8mx1.png" /img>
<img src="http://i.imgur.com/gVGGycg.png" /img>
</p>
